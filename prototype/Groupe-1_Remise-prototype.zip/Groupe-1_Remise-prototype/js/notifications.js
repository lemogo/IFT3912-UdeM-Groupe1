$(document).ready(function(){
	$(".alert .deleteNotification").click(function(){
		$(this).parent().fadeOut(500);
	});
});